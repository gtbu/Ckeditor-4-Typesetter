# LayoutManager  - adapted fork of https://www.drupal.org/project/ckeditor_layout_manager  - GPL2
https://www.drupal.org/project/ckeditor_layout_manager/releases/1.0.x-dev

TODO: Write a plugin description

## Configuration

#### config.extraPlugins = "layoutmanager"

#### config.layoutmanager_loadbootstrap = true/false (false by default - embedded bootstrap.css is not loaded)
#### config.layoutmanager_allowedContent (all tags are allowed by default)
#### config.layoutmanager_buttonboxWidth = 58 (the width of each layout-preview button in the dialog)

#### Name for adding into the toolbar : "LayoutManager"

## Events

layoutmanager:layout-inserted - fired when layout is inserted

## Dependencies
https://jquery.com/
