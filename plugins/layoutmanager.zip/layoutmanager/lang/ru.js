CKEDITOR.plugins.setLang('layoutmanager', 'ru', {
    title: 'Шаблоны разметки',
    addLayoutDialogTitle: 'Выбор шаблона',
    manageLayoutDialogTitle: 'Замена шаблона',
    removeLayoutMenuLabel: 'Удалить шаблон',
    manageLayoutMenuLabel: 'Заменить шаблон'
});
