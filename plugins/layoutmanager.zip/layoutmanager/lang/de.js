CKEDITOR.plugins.setLang('layoutmanager', 'de', {
    title: 'Layouts',
    addLayoutDialogTitle: 'Layout auswählen',
    manageLayoutDialogTitle: 'Layout ersetzen', 
    removeLayoutMenuLabel: 'Layout entfernen',
    manageLayoutMenuLabel: 'Layout ersetzen'
});
