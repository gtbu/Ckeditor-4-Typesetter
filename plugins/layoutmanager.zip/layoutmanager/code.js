/*  Layoutmanager - 
* Drupal Author: Radoslav Petkov GPL-2
* adapted 2025 github.com/gtbu 
*/


LayoutManager.prototype.changeLayoutAction = function (newLayoutName) {
    var editor = this.editor;
    var selectedWidget = editor.layoutmanager.selectedWidget; 

    if (!selectedWidget || selectedWidget.name === newLayoutName) {
        // No widget selected or layout is already the desired one
        return;
    }

    // --- 1. Get Content ---
    var savedContent = [];
    var oldEditables = selectedWidget.editables;
    // Iterate using keys provided by CKEditor's structure for editables
    for (var editableName in oldEditables) {
        if (oldEditables.hasOwnProperty(editableName)) {
            // Ensure we get the actual editable instance if needed, or just its data
            var editable = selectedWidget.editables[editableName];
            if (editable && typeof editable.getData === 'function') {
                 // Store content associated with its original editable name (like 'layoutColumn1')
                 // Or store in order if names aren't reliable across layouts
                 savedContent.push(editable.getData());
            }
        }
    }
    
    var widgetElement = selectedWidget.element;

    editor.fire('lockSnapshot'); // Prevent undo snapshots during the process

    var range = editor.createRange();
    try {
        range.setStartBefore(widgetElement);
        range.collapse(true); // Collapse the range to a single point
        editor.getSelection().selectRanges([range]); // Select the position
    } catch (e) {
        console.error("LayoutManager: Error setting range before widget.", e);
        editor.fire('unlockSnapshot');
        return; // Abort if we can't set the position
    }

    editor.widgets.destroy(selectedWidget);
    
    editor.execCommand(newLayoutName);

    var newWidget = editor.widgets.selected.length > 0 ? editor.widgets.selected[0] : null;

    if (!newWidget || newWidget.name !== newLayoutName) {
        
        var walkerRange = range.clone();
        walkerRange.enlarge(CKEDITOR.ENLARGE_ELEMENT);
        var node = walkerRange.getNextNode(function(el) {
             return el.type == CKEDITOR.NODE_ELEMENT && el.hasClass('layoutmanager'); // Check for the main widget class
        });
        if (node) {
            newWidget = editor.widgets.getByElement(node);
        }
    }


    if (newWidget && newWidget.name === newLayoutName) {
        var newEditables = newWidget.editables;
        var newEditableKeys = Object.keys(newEditables); // Get keys like 'layoutColumn1', 'layoutColumn2'
        var newColumnsCount = newEditableKeys.length;
        var oldColumnsCount = savedContent.length;

        for (var i = 0; i < newColumnsCount; i++) {
            var currentEditableKey = newEditableKeys[i];
            var currentEditable = newEditables[currentEditableKey];

            if (currentEditable && savedContent[i] !== undefined) {
                currentEditable.setData(savedContent[i]);
            }
        }

        // Handle content merging if the number of columns decreased
        if (newColumnsCount < oldColumnsCount) {
            var lastEditableKey = newEditableKeys[newColumnsCount - 1];
            var lastEditable = newEditables[lastEditableKey];
            if (lastEditable) {
                var extraContent = '';
                for (var j = newColumnsCount; j < oldColumnsCount; j++) {
                    extraContent += savedContent[j]; // Append content from removed columns
                }
                // Append the extra content to the existing content of the last column
                lastEditable.setData(lastEditable.getData() + extraContent);
            }
        }
        
    } else {
        console.error("LayoutManager: Failed to find the newly inserted widget for layout:", newLayoutName);
    }

    editor.fire('unlockSnapshot');
    editor.fire('saveSnapshot'); 
    editor.focus(); // Refocus the editor
};