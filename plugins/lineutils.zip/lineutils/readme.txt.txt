https://ckeditor.com/cke4/addon/lineutils  License: GPL, LGPL, MPL, CKSource CDL

https://github.com/ckeditor/ckeditor-dev/tree/master/plugins/lineutils