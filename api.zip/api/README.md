# API

This plugin provides APIs for other plugins to work with browser windows, dialog UI elements, media elements, htmlParser elements, URLs and *XMLHttpRequest*s.

## Demo

- [Classic Editor](https://akilli.github.io/ckeditor4-build-classic/demo)
- [Inline Editor](https://akilli.github.io/ckeditor4-build-inline/demo)
